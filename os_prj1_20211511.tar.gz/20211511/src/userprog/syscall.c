#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"

#include "lib/user/syscall.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "filesys/file.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

//TODO: 2-1. User Memory Access
void is_invalid_ptr(const void *vaddr) {
	//Null pointer
	if (vaddr == NULL) exit(-1);
	//Pointer to kernel address space
	if (!is_user_vaddr(vaddr) || is_kernel_vaddr(vaddr)) exit(-1);
	//Unmapped virtual memory
	if (pagedir_get_page(thread_current()->pagedir, vaddr) == NULL) exit(-1);
}
///////////////////////////////

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  //TODO: 3-1. System Call Handler
  switch(*(uint32_t *)(f->esp)) {
	case SYS_HALT:
		halt();
		break;

	case SYS_EXIT:
		is_invalid_ptr(f->esp + 4);
		exit((int)*(uint32_t*)(f->esp + 4));
		break;

	case SYS_EXEC:
		is_invalid_ptr(f->esp + 4);
		f->eax = exec((const char *)*(uint32_t*)(f->esp + 4));
		break;

	case SYS_WAIT:
                is_invalid_ptr(f->esp + 4);
		f->eax = wait((pid_t)*(uint32_t*)(f->esp + 4));
		break;

	case SYS_READ:
                is_invalid_ptr(f->esp + 4);
                is_invalid_ptr(f->esp + 8);
                is_invalid_ptr(f->esp + 12);
		f->eax = read((int)*(uint32_t*)(f->esp + 4), (void *)*(uint32_t*)(f->esp + 8), (unsigned)*(uint32_t*)(f->esp + 12));
		break;

	case SYS_WRITE:
                is_invalid_ptr(f->esp + 4);
                is_invalid_ptr(f->esp + 8);
                is_invalid_ptr(f->esp + 12);
                f->eax = write((int)*(uint32_t*)(f->esp + 4), (const void *)*(uint32_t*)(f->esp + 8), (unsigned)*(uint32_t*)(f->esp + 12));
		break;

	//TODO: 5-5. Additional System Call Handler
	case SYS_FIBONACCI:
		is_invalid_ptr(f->esp + 4);
		f->eax = fibonacci((int)*(uint32_t*)(f->esp + 4));
		break;

	case SYS_MAX:
		is_invalid_ptr(f->esp + 4);
                is_invalid_ptr(f->esp + 8);
                is_invalid_ptr(f->esp + 12);
		is_invalid_ptr(f->esp + 16);
		f->eax = max_of_four_int((int)*(uint32_t*)(f->esp + 4), (int)*(uint32_t*)(f->esp + 8), (int)*(uint32_t*)(f->esp + 12), (int)*(uint32_t*)(f->esp + 16));
		break;
  }
 // thread_exit ();
}

//TODO: 4-1. System Call Implementation
void halt(void){
	shutdown_power_off();
}

void exit(int status){
	printf("%s: exit(%d)\n", thread_current()->name, status);

	thread_current()->exit_status = status;
	thread_exit();	
}

pid_t exec(const char *file) {
	return process_execute(file);
}

int wait(pid_t pid) {
	return process_wait(pid);
}

int read(int fd, void *buffer, unsigned size){
	//STDIN
	if (fd == 0){
		*(char *)buffer = input_getc();
		return size;
	}
	return -1;
}


int write(int fd, const void *buffer, unsigned size){
	//STDOUT
	if (fd == 1){
		putbuf(buffer, size);
		return size;
	}
	return -1;
}

//TODO: 5-5. Additional System Call Implementation
int fibonacci(int n){
	int f1 = 0, f2 = 1, N;

	if (n <= 1) return n;
	
	for (int i = 1; i < n; i++) {
		N = f1 + f2;
		f1 = f2;
		f2 = N;
	}

	return N;
}

int max_of_four_int(int a, int b, int c, int d){
	int max;

	max = a;
	if (max < b) max = b;
	if (max < c) max = c;
	if (max < d) max = d;

	return max;
}
