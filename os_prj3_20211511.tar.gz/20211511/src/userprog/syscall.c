#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"

#include "lib/user/syscall.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "filesys/file.h"

#include "threads/synch.h"

static void syscall_handler (struct intr_frame *);

struct lock f_lock;

void
syscall_init (void) 
{
	lock_init(&f_lock);
	intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

//TODO: 2-1. User Memory Access
void is_invalid_ptr(const void *vaddr) {
	//Null pointer
	if (vaddr == NULL) exit(-1);
	//Pointer to kernel address space
	if (!is_user_vaddr(vaddr) || is_kernel_vaddr(vaddr)) exit(-1);
	//Unmapped virtual memory
	if (pagedir_get_page(thread_current()->pagedir, vaddr) == NULL) exit(-1);
}
///////////////////////////////

//----------------------project #2-----------------------
//TODO: 4-2 null fd check
void is_null(int fd){
	if (thread_current()->fd[fd] == NULL) exit(-1);
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  //TODO: 3-1. System Call Handler
  switch(*(uint32_t *)(f->esp)) {
	case SYS_HALT:
		halt();
		break;

	case SYS_EXIT:
		is_invalid_ptr(f->esp + 4);
		exit((int)*(uint32_t*)(f->esp + 4));
		break;

	case SYS_EXEC:
		is_invalid_ptr(f->esp + 4);
		f->eax = exec((const char *)*(uint32_t*)(f->esp + 4));
		break;

	case SYS_WAIT:
                is_invalid_ptr(f->esp + 4);
		f->eax = wait((pid_t)*(uint32_t*)(f->esp + 4));
		break;

	case SYS_READ:
                is_invalid_ptr(f->esp + 4);
                is_invalid_ptr(f->esp + 8);
                is_invalid_ptr(f->esp + 12);
		f->eax = read((int)*(uint32_t*)(f->esp + 4), (void *)*(uint32_t*)(f->esp + 8), (unsigned)*(uint32_t*)(f->esp + 12));
		break;

	case SYS_WRITE:
                is_invalid_ptr(f->esp + 4);
                is_invalid_ptr(f->esp + 8);
                is_invalid_ptr(f->esp + 12);
                f->eax = write((int)*(uint32_t*)(f->esp + 4), (const void *)*(uint32_t*)(f->esp + 8), (unsigned)*(uint32_t*)(f->esp + 12));
		break;

	//TODO: 5-5. Additional System Call Handler
	case SYS_FIBONACCI:
		is_invalid_ptr(f->esp + 4);
		f->eax = fibonacci((int)*(uint32_t*)(f->esp + 4));
		break;

	case SYS_MAX:
		is_invalid_ptr(f->esp + 4);
                is_invalid_ptr(f->esp + 8);
                is_invalid_ptr(f->esp + 12);
		is_invalid_ptr(f->esp + 16);
		f->eax = max_of_four_int((int)*(uint32_t*)(f->esp + 4), (int)*(uint32_t*)(f->esp + 8), (int)*(uint32_t*)(f->esp + 12), (int)*(uint32_t*)(f->esp + 16));
		break;

	//TODO: --------------------------prj#2--------------------------------
	//1-1. System Call Handler
	case SYS_CREATE:
		is_invalid_ptr(f->esp + 4);
        	is_invalid_ptr(f->esp + 8);
        	f->eax = create((const char *)*(uint32_t*)(f->esp + 4), (unsigned)*(uint32_t*)(f->esp + 8));
        	break;

	case SYS_REMOVE:
                is_invalid_ptr(f->esp + 4);
                f->eax = remove((const char *)*(uint32_t*)(f->esp + 4));
                break;

	case SYS_OPEN:
                is_invalid_ptr(f->esp + 4);
                f->eax = open((const char *)*(uint32_t*)(f->esp + 4));
                break;
	
	case SYS_CLOSE:
                is_invalid_ptr(f->esp + 4);
		close((int)*(uint32_t*)(f->esp + 4));
                break;
	
	case SYS_FILESIZE:
                is_invalid_ptr(f->esp + 4);
                f->eax = filesize((int)*(uint32_t*)(f->esp + 4));
                break;

	case SYS_SEEK:
                is_invalid_ptr(f->esp + 4);
                is_invalid_ptr(f->esp + 8);
		seek((int)*(uint32_t*)(f->esp + 4), (unsigned)*(uint32_t*)(f->esp + 8));
                break;

	case SYS_TELL:
                is_invalid_ptr(f->esp + 4);
                f->eax = tell((int)*(uint32_t*)(f->esp + 4));
                break;
  }
 // thread_exit ();
}

//TODO: 4-1. System Call Implementation
void halt(void){
	shutdown_power_off();
}

void exit(int status){
	printf("%s: exit(%d)\n", thread_current()->name, status);
	thread_current()->exit_status = status;

//TODO: --------------------------prj#2--------------------------------
//4-1. Close all files when process exits
	for (int i = 2; i < 128; i++) {
		if (thread_current()->fd[i] != NULL) close(i);
	}
	//thread_current()->exit_status = status;
	thread_exit();	
}

pid_t exec(const char *file) {
	return process_execute(file);
}

int wait(pid_t pid) {
	return process_wait(pid);
}

//TODO: --------------------------prj#2--------------------------------
//3-1. Read and Write
int read(int fd, void *buffer, unsigned size){
        //STDIN
	//if (is_user_vaddr(buffer) == 0) exit(-1);
	is_invalid_ptr(buffer);
	lock_acquire(&f_lock);

        char byte;
	int i;

        if (fd == 0){
		for (i = 0; i < size; i++) {
			byte = input_getc();
			//buffer[i++] = byte;
			if (byte == '\0') break;
        	}
		lock_release(&f_lock);
		return i;
	}
        else if (fd >= 2){
                //is_null(fd);
		if (thread_current()->fd[fd] == NULL) {
			lock_release(&f_lock);
			exit(-1);
		}
		lock_release(&f_lock);
                return file_read(thread_current()->fd[fd], buffer, size);
        }

	lock_release(&f_lock);
        return -1;
}

//TODO: 3-3. check denying write
int write(int fd, const void *buffer, unsigned size){
	//STDOUT
	//if (is_user_vaddr(buffer) == 0) exit(-1);
	is_invalid_ptr(buffer);
	lock_acquire(&f_lock);

	if (fd == 1){
		putbuf((char*)buffer, size);
		lock_release(&f_lock);
		return size;
	}
	else if (fd >= 2){
		//is_null(fd);
		if (thread_current()->fd[fd] == NULL) {
			lock_release(&f_lock);
			exit(-1);
		}
		if (thread_current()->fd[fd]->deny_write) {
			file_deny_write(thread_current()->fd[fd]);
			//printf("deny!!!!!!!!!!!!!!!!!\n");
		}
		
		int ret = file_write(thread_current()->fd[fd], buffer, size);
		lock_release(&f_lock);
		return ret;
	}

	lock_release(&f_lock);
	return -1;
}

//TODO: 5-5. Additional System Call Implementation
int fibonacci(int n){
	int f1 = 0, f2 = 1, N;

	if (n <= 1) return n;
	
	for (int i = 1; i < n; i++) {
		N = f1 + f2;
		f1 = f2;
		f2 = N;
	}

	return N;
}

int max_of_four_int(int a, int b, int c, int d){
	int max;

	max = a;
	if (max < b) max = b;
	if (max < c) max = c;
	if (max < d) max = d;

	return max;
}

//TODO: --------------------------prj#2--------------------------------
//1-1. System Call Handler
bool create(const char *file, unsigned initial_size){
	//TODO: 4-1. null check
	if (file == NULL) exit(-1);

	return filesys_create(file, initial_size);
}

bool remove(const char *file){
	if (file == NULL) exit(-1);

	return filesys_remove(file);
}

int open(const char *file){
	//TODO: 4-1. null check
	is_invalid_ptr(file);
	if (file == NULL) exit(-1);

	lock_acquire(&f_lock);
	struct file *f = filesys_open(file);

	//return file desriptor
	if (f != NULL) {
		//if (strcmp(thread_name(), file) == 0) file_deny_write(f);
		for (int i = 2; i < 128; i++) {
			if (thread_current()->fd[i] == NULL) {
				//TODO: 3-2 denying write
				if (strcmp(thread_current()->name, file) == 0) file_deny_write(f);

				thread_current()->fd[i] = f;
				lock_release(&f_lock);
				
				return i;
			}
		}
	}
	//file could not be open or no available descriptor -> return -1

	lock_release(&f_lock);
	return -1;
}

void close(int fd){
	is_null(fd);
	if (fd >= 2) {
		file_close(thread_current()->fd[fd]);
		thread_current()->fd[fd] = NULL;
	}
}

int filesize(int fd){
	is_null(fd);
	if (fd >= 2) {
		return file_length(thread_current()->fd[fd]);
	}
}

void seek(int fd, unsigned position){
	is_null(fd);
	
	file_seek(thread_current()->fd[fd], position);
}

unsigned tell(int fd){
	is_null(fd);
	if (fd >= 2) {
		return file_tell(thread_current()->fd[fd]);
	}
}

