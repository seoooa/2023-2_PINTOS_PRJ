#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "threads/malloc.h"
#include "threads/interrupt.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "userprog/pagedir.h"
#include "vm/page.h"
#include "vm/frame.h"
#include "vm/swap.h"

//----------------------project #4-----------------------
//TODO: 1-3. implement vm_entry functions
static unsigned vm_hash_func(const struct hash_elem *e, void *aux) {
        struct vm_entry *vme = hash_entry(e, struct vm_entry, elem);

        return hash_int((int)vme->vaddr);
}

static bool vm_less_func(const struct hash_elem *a, const struct hash_elem *b, void *aux) {
        struct vm_entry *vme1 = hash_entry(a, struct vm_entry, elem);
        struct vm_entry *vme2 = hash_entry(b, struct vm_entry, elem);

        return vme1->vaddr < vme2->vaddr;
}

static void vm_free_func(struct hash_elem *e, void *aux) {
        struct vm_entry *vme = hash_entry(e, struct vm_entry, elem);

        if (vme->is_loaded) {
                void *phy_addr = pagedir_get_page(thread_current()->pagedir, vme->vaddr);
                free_page(phy_addr);
                pagedir_clear_page(thread_current()->pagedir, vme->vaddr);
        }

        free(vme);
}

void vm_init(struct hash *vm) {
        hash_init(vm, vm_hash_func, vm_less_func, NULL);
}

void vm_destroy(struct hash *vm) {
        hash_destroy(vm, vm_free_func);
}

bool insert_vme(struct hash *vm, struct vm_entry *vme) {
        if (hash_insert(vm, &(vme->elem)) == NULL) return true;
        else return false;
}

bool delete_vme(struct hash *vm, struct vm_entry *vme) {
        if (hash_delete(vm, &(vme->elem)) == NULL) {
                free(vme);
                return false;
        }
        else {
                free(vme);
                return true;
        }
}

struct vm_entry *find_vme(void *vaddr) {
        struct vm_entry vme;
        struct hash_elem *e;

        vme.vaddr = pg_round_down(vaddr);
        e = hash_find(&thread_current()->vm, &(vme.elem));

        if (e == NULL) return NULL;
        else return hash_entry(e, struct vm_entry, elem);
}

bool load_file(void *kaddr, struct vm_entry *vme) {
        int n_read = file_read_at(vme->file, kaddr, vme->read_bytes, vme->offset);
	//printf("read_At:  %d\n", n_read); 
	//printf("vme->read_bytes : %d\n", vme->read_bytes);
	//printf("file_read: %d\n", file_read (vme->file, kaddr, vme->read_bytes)); 

        if(n_read == (int)(vme->read_bytes)) {
		memset(kaddr + vme->read_bytes, 0, vme->zero_bytes);
                return true;
        }
        else return false;
}
