#include "vm/swap.h"
#include "vm/frame.h"
#include "vm/page.h"

//----------------------project #4-----------------------
//TODO: 2-3. implement swap
const size_t BLOCK_SECTOR_CNT = PGSIZE / BLOCK_SECTOR_SIZE;

void swap_init(void) {
        swap_partition = block_get_role(BLOCK_SWAP);
        if (swap_partition == NULL) return;

        swap_bitmap = bitmap_create(block_size(swap_partition) / BLOCK_SECTOR_CNT);
        if (swap_bitmap == NULL) return;

        bitmap_set_all(swap_bitmap, 0);
        lock_init(&swap_lock);
}

void swap_in(size_t used_index, void *kaddr) {
        lock_acquire(&swap_lock);

        if (!bitmap_test(swap_bitmap, used_index)) return;

        for (int i = 0; i < BLOCK_SECTOR_CNT; i++) {
                block_read(swap_partition, used_index * BLOCK_SECTOR_CNT + i, kaddr + i * BLOCK_SECTOR_SIZE);
        }

        bitmap_reset(swap_bitmap, used_index);
        lock_release(&swap_lock);
}

size_t swap_out(void *kaddr) {
        lock_acquire(&swap_lock);

        size_t swap_index = bitmap_scan(swap_bitmap, 0, 1, false);

        if (swap_index == BITMAP_ERROR) return BITMAP_ERROR;

        for (int i = 0; i < BLOCK_SECTOR_CNT; i++) {
                block_write(swap_partition, swap_index * BLOCK_SECTOR_CNT + i, kaddr + i * BLOCK_SECTOR_SIZE);
        }

        bitmap_set(swap_bitmap, swap_index, true);
        lock_release(&swap_lock);

        return swap_index;
}
