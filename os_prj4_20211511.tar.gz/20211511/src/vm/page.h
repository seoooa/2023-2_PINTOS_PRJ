#ifndef VM_PAGE_H
#define VM_PAGE_H

#include <hash.h>
#include <list.h>
#include "threads/thread.h"
#include "threads/vaddr.h"

#define VM_BIN 0        /* binary file */
#define VM_ANON 1       /* anonymous file */

//TODO: 1-2. implement vm_entry struct and prototype
struct vm_entry{
        uint8_t type;   /* VM_BIN or VM_ANON */

        void *vaddr;    /* virtual address */

        bool writable;  /* True: writable False: not writable */
        bool is_loaded; /* loaded on physical mem or not */
        bool holded;    /* False: not writable  */

        size_t offset;
        size_t read_bytes;
        size_t zero_bytes;

        size_t swap_slot;

        struct hash_elem elem;  /* hash table element */

        struct file *file;
        //char *file_name;
        struct list_elem mmap_elem;
};

void vm_init(struct hash *vm);
void vm_destroy(struct hash *vm);

bool insert_vme(struct hash *vm, struct vm_entry *vme);
bool delete_vme(struct hash *vm, struct vm_entry *vme);
struct vm_entry *find_vme(void *vaddr);

bool load_file(void *kaddr, struct vm_entry *vme);

//TODO 2-1. implement page struct
struct page {
        void *kaddr;
        struct vm_entry *vme;
        struct thread *thread;
        struct list_elem lru;
};

#endif
