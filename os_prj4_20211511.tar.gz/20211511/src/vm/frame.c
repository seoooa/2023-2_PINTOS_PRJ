#include "vm/frame.h"

//TODO 2-2. implement LRU Algorithm

 void lru_list_init(void) {
        list_init(&lru_list);
        lock_init(&lru_lock);
        lru_clock = NULL;
}

void add_page_to_lru_list(struct page *page) {
        if (page != NULL) {
                lock_acquire(&lru_lock);
                list_push_back(&lru_list, &(page->lru));
                lock_release(&lru_lock);
        }
}

void del_page_from_lru_list(struct page *page) {
        if (page != NULL) {
                if (lru_clock == page) lru_clock = list_next(lru_clock);

                list_remove(&page->lru);
        }
}

void free_page(void *kaddr) {
        struct list_elem *e;
        struct page *p = NULL;

        lock_acquire(&lru_lock);
        for (e = list_begin(&lru_list); e != list_end(&lru_list); e = list_next(e)) {
                p = list_entry(e, struct page, lru);
                if (p->kaddr == kaddr) {
                        __free_page(p);
                        break;
                }
        }
        lock_release(&lru_lock);
}

void __free_page(struct page *page) {
        if (page != NULL) {
                palloc_free_page(page->kaddr);
                del_page_from_lru_list(page);
        }

        free(page);
}

static struct list_elem *get_next_lru_clock(void) {

        struct list_elem *e;

        if (list_empty(&lru_list)) return NULL;

        if (lru_clock == NULL || lru_clock == list_end(&lru_list)) {
                e = list_begin(&lru_list);
                lru_clock = list_entry(e, struct page, lru);
                return e;
        }

        if (list_next(lru_clock) != list_end(&lru_list)) e = list_next(&lru_list);
        else e = list_begin(lru_clock);

        lru_clock = list_entry(e, struct page, lru);

        return e;
}

void try_to_free_pages(void) {
        struct page *p;
        struct list_elem *e;

        lock_acquire(&lru_lock);

        if (list_empty(&lru_list)) {
                lock_release(&lru_lock);
                return;
        }

        while(1) {
                e = get_next_lru_clock();

                if (e == NULL) {
                        lock_release(&lru_lock);
                        return;
                }

                p = list_entry(e, struct page, lru);

                if (pagedir_is_accessed(p->thread->pagedir, p->vme->vaddr)) {
                        pagedir_set_accessed(p->thread->pagedir, p->vme->vaddr, false);
                        continue;
                }

                switch(p->vme->type) {
                        case VM_BIN:
                                if (pagedir_is_dirty(p->thread->pagedir, p->vme->vaddr)) {
                                        p->vme->type = VM_ANON;
                                        p->vme->swap_slot = swap_out(p->kaddr);
                                }
                                break;
                        case VM_ANON:
                                p->vme->swap_slot = swap_out(p->kaddr);
                                break;
                }

                p->vme->is_loaded = false;
                pagedir_clear_page(p->thread->pagedir, p->vme->vaddr);
                __free_page(p);

                break;
        }
        lock_release(&lru_lock);

        return;
}

//TODO: 2-6. implement alloc_page
struct page *alloc_page(enum palloc_flags flags) {

        //lock_acquire(&lru_lock);

        if ((flags & PAL_USER) == 0) {
               // lock_release(&lru_lock);
                return NULL;
        }

        void* kaddr = palloc_get_page(flags);
        while(kaddr == NULL) {
                try_to_free_pages();
                kaddr = palloc_get_page(flags);
        }

        struct page *new_page = malloc(sizeof(struct page));

        if (new_page == NULL) {
                palloc_free_page(kaddr);

               // lock_release(&lru_lock);
                return NULL;
        }

        new_page->thread = thread_current();
        new_page->kaddr = kaddr;

        add_page_to_lru_list(new_page);

        //lock_release(&lru_lock);

        return new_page;
}
